#ifndef _CLAW_H_
#define _CLAW_H_

void clawSet(int speed);

#endif
