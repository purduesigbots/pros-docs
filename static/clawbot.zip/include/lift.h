#ifndef _LIFT_H_
#define _LIFT_H_

void liftSet(int speed);

#endif /* end of include guard: _LIFT_H_ */
