#ifndef _PORTS_H_
#define _PORTS_H_

// MOTOR DEFINITIONS
#define CHASSIS_LEFT_MOTOR    2
#define CHASSIS_RGHT_MOTOR    3
#define LIFT_MOTOR            8
#define CLAW_MOTOR            9


#endif /* end of include guard: _PORTS_H_ */
