#include "main.h"    // includes API.h and other headers
#include "chassis.h" // redundant, but ensures that the corresponding header file (chassis.h) is included
#include "ports.h"

void chassisSet(int left, int right) {
  motorSet(CHASSIS_LEFT_MOTOR, left);
  motorSet(CHASSIS_RGHT_MOTOR, right);
}
