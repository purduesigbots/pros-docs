#include "main.h"
#include "claw.h"
#include "ports.h"

void clawSet(int speed) {
  // need to invert claw direction
  motorSet(CLAW_MOTOR, -speed);
}
